x=int(input("enter number"))
z=x
a=0
while x>0:
    rem=x%10
    a=rem+a*10
    x=x//10
if(z==a):
    print("the palindrome number")
else:
    print("not a palindrome number")
    